package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;

//import org.json.*;
import org.json.JSONException;
import org.json.simple.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.concurrent.TimeoutException;

import com.example.test.databinding.ActivityMainBinding;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DeliverCallback;

public class MainActivity extends AppCompatActivity {
    final String QUEUE_NAME = "phone1";//"phone2" for player2
    ConnectionFactory factory = new ConnectionFactory();
    Channel channel;
    Connection connection = null;

    Thread consumerThread;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LayoutInflater layoutInflater = LayoutInflater.from(this);

        ActivityMainBinding binding = ActivityMainBinding.inflate(layoutInflater);
        setContentView(binding.getRoot());


        receiving(binding);
    }

    private void setupConnectionFactory() {
        factory.setHost("172.27.212.54");
        factory.setPort(5672);
        factory.setUsername("admin1");
        factory.setPassword("admin123");
    }

    private void setupConnection() {
        setupConnectionFactory();

        try {
            connection = factory.newConnection();
        } catch (IOException | TimeoutException e) {
            e.printStackTrace();
        }
        channel = null;
        try {
            channel = connection.createChannel();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void receiving(ActivityMainBinding binding) {
        consumerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                setupConnection();

                DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                    String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
                    try {
                        parse_update(message, binding);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }finally {
                        channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
                    }
                };
                try {
                    channel.basicConsume(QUEUE_NAME, false, deliverCallback, consumerTag -> {
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
        consumerThread.start();
    }

    private void parse_update(String message, ActivityMainBinding binding) throws JSONException {
        JSONObject player_status = (JSONObject) JSONValue.parse(message);
        HashMap p1 = (HashMap) player_status.get("p1");
        HashMap p2 = (HashMap) player_status.get("p2");
        String p1_hp = p1.get("hp").toString();
        String p1_action = p1.get("action").toString();
        String p1_bullets = p1.get("bullets").toString();
        String p1_grenades = p1.get("grenades").toString();
        String p1_shield_time = p1.get("shield_time").toString();
        String p1_shield_health = p1.get("shield_health").toString();
        String p1_num_deaths = p1.get("num_deaths").toString();
        String p1_num_shield = p1.get("num_shield").toString();
        String p2_hp = p2.get("hp").toString();
        String p2_action = p2.get("action").toString();
        String p2_bullets = p2.get("bullets").toString();
        String p2_grenades = p2.get("grenades").toString();
        String p2_shield_time = p2.get("shield_time").toString();
        String p2_shield_health = p2.get("shield_health").toString();
        String p2_num_deaths = p2.get("num_deaths").toString();
        String p2_num_shield = p2.get("num_shield").toString();
        String p1_display = "hp: " + p1_hp + "\naction: " + p1_action + "\nbullets: " + p1_bullets + "\ngrenades: " + p1_grenades + "\nshield_time: " + p1_shield_time + "\nshield_health: " + p1_shield_health + "\nnum_deaths: " + p1_num_deaths + "\nnum_shield: " + p1_num_shield;
        String p2_display = "hp: " + p2_hp + "\naction: " + p2_action + "\nbullets: " + p2_bullets + "\ngrenades: " + p2_grenades + "\nshield_time: " + p2_shield_time + "\nshield_health: " + p2_shield_health + "\nnum_deaths: " + p2_num_deaths + "\nnum_shield: " + p2_num_shield;
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                binding.player1Status.setText(p1_display);
                binding.player2Status.setText(p2_display);
            }
        };
        runOnUiThread(runnable);
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        consumerThread.interrupt();
    }

}